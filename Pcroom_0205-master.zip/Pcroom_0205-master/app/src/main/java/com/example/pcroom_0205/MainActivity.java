package com.example.pcroom_0205;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.sql.Time;

public class MainActivity extends AppCompatActivity {

    int num = 9;
    Button[] btns = new Button[num];
    TextView[] tvs = new TextView[num];
    TimeThread[] threads= new TimeThread[9];

    private final int TAG_BTN = 0, TAG_TXT = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        for (int i = 0; i < num; i++) {
            int btnID = getResources().getIdentifier("btn" + (i + 1), "id", getPackageName());
            int tvsID = getResources().getIdentifier("tv" + (i + 1), "id", getPackageName());
            btns[i] = findViewById(btnID);
            tvs[i] = (TextView) findViewById(tvsID);
        }

        for (int i = 0; i < btns.length; i++) {
            final int j = i;
            btns[i].setOnClickListener((new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    TimeThread th = new TimeThread(tvs[j], btns[j]);
                    th.start();
                }
            }));


        }


    }


    Handler handler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(@NonNull Message msg) {
            if (msg.arg2 == TAG_TXT) {

                ((TextView) msg.obj).setText((msg.arg1 + "원"));

            } else {
                ((Button) (msg.obj)).setText(msg.arg1 / 60 + ":" + msg.arg1 % 60 + "");

            }


        }
    };


    class TimeThread extends Thread {

        private Button btn;
        private TextView tv;

        TimeThread(TextView tv, Button btn) {
            this.btn = btn;
            this.tv = tv;
        }

        @Override
        public void run() {
            int i = 0;
            int j = 0;
            while (true) {

                //메시지 2개가 한번에 가나?
                //그럼 어떻게 구별?
                //운비쌤한테 물어봐야함
                Message msg = new Message();
                Message msg2 = new Message();


                if (i % 10 == 0) {
                    j += 100;
                }


                msg.obj = tv;
                msg.arg1 = j;
                msg.arg2 = TAG_TXT;

                handler.sendMessage(msg);

                i++;

                msg2.obj = btn;
                msg2.arg1 = i;
                msg2.arg2 = TAG_BTN;


                handler.sendMessage(msg2);


                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    return;
                }


            }


        }
    }


}