package com.example.a20210129;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

//Android에서 Adapter를 custom 할 수 있도록 기본  Adapter 형태를 제공하고
// => BaseAdapter를 상속받는다
public class BoardAdapter extends BaseAdapter {
    //Field를 정의 => 클래스의 속성, 클래스변수(전역변수)
    private Context co;// Activity  화면 정보
    private int layout;// 항목이 될 뷰(boardlist)의 id값 의미
    private ArrayList<String> data; //보여질 데이터
    private LayoutInflater inflater;//App에 화면 띄우는 역할

    //Adapter가 하는일!!
    //항목 디자인 Layout id(int) data(ArrayList) 전달 받아서
    // data의 개수만큼 Layout 복사하여
    // data를 layout에 표현

    // 한 단계 더 들어가서,
    // 항목 디자인 Layout을 App에 띄움 -> inflater(대표적으로 findViewByID, setContentView)

    //그런데 !!! inflate는 Activity만 할수 있음... Adapter는 못함
    //그래서 Activity의 정보인 Context를 전달받아 inflate 기능만 추출해야한다

    //먼저 생성자 메소드를 통해 Field에 정의된 변수 전달 받기
    // => 객체 생성할 때 호출되는 메소드! (주로 Field 초기화(변수에 최초로 값을 지정)할때 사용)

    public BoardAdapter(Context co, int layout, ArrayList<String> data) {
        this.co = co;
        this.layout = layout;
        this.data = data;
        //context에서 Layoutinflater 추출
        this.inflater = (LayoutInflater) co.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {// 전체 ListView 항목의 개수를 리턴!
        return data.size();
    }

    @Override
    public Object getItem(int position) {// position 번째의 데이터를 리턴
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {// position 번째의 아이디를 리턴
        return position;
    }

    //★★★★★★★
    //adapter의 핵심역할
    // position 번째의 항목을 만드는 method -> inflate
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //항목을 만들떄마다 inflate를 하게 돼면 핸드폰 버벅
        // 최초 1회 inflate 수행
        // 다음부터는 재활용
        if (convertView == null) {//최초로 만들어지는 거라면!
            convertView = inflater.inflate(layout, parent, false);
        }
        //board_list안에서 찾겠습니다.
        TextView tv = convertView.findViewById(R.id.tv_title);
        tv.setText(data.get(position));

        //버튼 ID로 findViewbyID
        Button btn = convertView.findViewById(R.id.btn_delete);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                data.remove(position);
                notifyDataSetChanged();
            }
        });


        return convertView;


    }
}
