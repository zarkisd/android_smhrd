package com.example.a20210129;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    Button btn_write, btn_login;
    TextView txt_hi, txt_list;
    ListView list_board;
    ArrayList<String> board_data = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_login = findViewById(R.id.btn_login);
        txt_hi = findViewById(R.id.txt_hi);
        list_board = findViewById(R.id.list_board);

        board_data.add("1. Android 개어려움");
        board_data.add("2. 예호 쌤 초밥 감사햅니다.");
        board_data.add("3. 집에 있는데 더 격하게 집에 가고싶다.");
        board_data.add("4. Android... 26살들아 부탁한다....");
        board_data.add("5. 창문으로 햇빛이 들어온다 눈부시다");
        board_data.add("6. 오늘은 금요일!!");

        //어댘터 생성, SetAdapter하면 끝
        BoardAdapter adapter=new BoardAdapter(MainActivity.this,R.layout.boardlist,board_data);

        list_board.setAdapter(adapter);


        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myintent = new Intent(MainActivity.this, Subctivity.class);
                startActivityForResult(myintent, 0);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == 0) {
                String id = data.getStringExtra("ID");
                txt_hi.setText(id + "님 환영합니다");


            }


        }
    }
}