package com.example.a20210201;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class AddList extends AppCompatActivity {

    Button btn_re;
    EditText edt_name, edt_url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_list);

        edt_name = (EditText) findViewById(R.id.edt_name);
        edt_url = (EditText) findViewById(R.id.edt_url);
        btn_re = findViewById(R.id.btn_re);


        btn_re.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edt_name.length() != 0 && edt_url.length() != 0) {
                    String[] new_data = new String[]{edt_name.getText().toString(), edt_url.getText().toString()};

                    Intent myintent = new Intent();

                    myintent.putExtra("value", new_data);
                    setResult(RESULT_OK, myintent);

                    finish();
                }
                else{
                    Toast.makeText(AddList.this, "fail", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }
}