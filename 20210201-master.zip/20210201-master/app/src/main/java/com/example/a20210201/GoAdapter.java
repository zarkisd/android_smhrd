package com.example.a20210201;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class GoAdapter extends BaseAdapter {
    private Context co;
    private int layout;
    private ArrayList<String[]> data;
    private LayoutInflater inflater;

    public GoAdapter(Context co, int layout, ArrayList<String[]> data) {
        this.co = co;
        this.layout = layout;
        this.data = data;
        this.inflater = (LayoutInflater) co.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {//최초로 만들어지는 거라면!
            convertView = inflater.inflate(layout, parent, false);
        }
        String[] a = data.get(position);
        TextView tv = convertView.findViewById(R.id.tv_homepage);
        tv.setText(a[0]);
        Button btn = convertView.findViewById(R.id.btn_go);


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.v("value", a[1]);
                Intent myIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(a[1]));
                ((MainActivity) co).startActivity(myIntent);
                /*intent를 실행시키는 메소드인
                startActivity는 Activity 클래스만 가지고 있다.
                현재 이곳은 adapter이기때문에 MainActivity에서 보내준화면 정보인
                Context객체를 사용하여 startActivity를 호출합니다.
                 */

                notifyDataSetChanged();
            }
        });

        /*
        tv.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(co);
                builder.setTitle("확인 창");
                builder.setMessage("정말 지울꺼냐");
                builder.setPositiveButton("예", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        data.remove(position);
                        notifyDataSetChanged();
                    }
                });
                builder.setNegativeButton("아니오", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(co, "아니오를 선택했습니다.", Toast.LENGTH_LONG).show();
                    }
                });
                builder.show();
                return true;
            }
        });
        */

        return convertView;
    }
}
