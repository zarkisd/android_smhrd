package com.example.a20210209_dodujee;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    final int num = 9;
    ImageView[] ivs = new ImageView[num];
    final int time = 30;
    int score = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView tv = findViewById(R.id.tv_time);
        TextView tv_score = findViewById(R.id.tv_score);

        for (int i = 0; i < num; i++) {
            final int temp = i;
            int ivsID = getResources().getIdentifier("imageView" + (i + 1), "id", getPackageName());

            //이미지뷰를 클릭했을때 on 상태인지 off상태인지 비교하자
            //이미지 뷰에 태그달기
            ivs[i] = findViewById(ivsID);
            ivs[i].setTag("off");

            new DoThread(i).start();


            ivs[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (ivs[temp].getTag().toString().equals("on")) {
                        score++;

                    } else {
                        score--;
                    }
                    tv_score.setText(score + "");
                }
            });




        }


    }

    Handler handler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(@NonNull Message msg) {
            ivs[msg.arg1].setImageResource(msg.arg2);
            ivs[msg.arg1].setTag(msg.obj);
        }
    };


    class DoThread extends Thread {
        // 이 쓰레드가 하는 일 -> ImageView에 두더지 사진 on off
        // but 쓰레드가 이미지를 바꿀수 없음 -> 핸들러 도움 필요함
        // 핸들러에 몇번째 두더지인지 알려줘야함 필드로 인덱스 받아야함
        private int index;

        public DoThread(int index) {
            this.index = index;
        }

        @Override
        public void run() {
            while (true) {
                while (true) {


                    try {
                        int offTime = (int) (Math.random() * 5000 + 500); //0.5~5.5
                        Thread.sleep(offTime);
                        //offTime만큼 쉬었으니 사진을 on으로 바꿔달라
                        Message msg = new Message();

                        msg.arg1 = index;
                        msg.arg2 = R.drawable.on;
                        msg.obj = "on";
                        handler.sendMessage(msg);

                        int onTime = (int) (Math.random() * 1000 + 500);
                        //핸들러에 한번 보낸 메시지는 재활용 불가능
                        Thread.sleep(onTime);
                        msg = new Message();

                        msg.arg1 = index;
                        msg.arg2 = R.drawable.off;
                        msg.obj = "off";
                        handler.sendMessage(msg);


                    } catch (InterruptedException e) {

                        return;
                    }
                }
            }

        }
    }





}




