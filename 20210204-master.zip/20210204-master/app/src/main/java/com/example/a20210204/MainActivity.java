package com.example.a20210204;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    TextView tv1, tv2;
    Button btn1, btn2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv1 = (TextView) findViewById(R.id.tv1);
        tv2 = (TextView) findViewById(R.id.tv2);

        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);


        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Thread 객체 생성
                //start호출
                TimeThread th1 = new TimeThread(tv1);
                th1.start();
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimeThread2 th2= new TimeThread2(tv2);
                th2.start();
            }
        });


    }

    Handler handler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(@NonNull Message msg) {
            ((TextView) (msg.obj)).setText(msg.arg1 + "");
        }
    };

    //innerclass Thread 설계
    class TimeThread extends Thread {
        //1. start 메소드 실행
        //2. run 메소드 실행
        //3 destroy 메소드 실행(사라질때)


        private TextView tv;
        // Thread 객체를 생성했을 때 값을 바꿔야하는 텍스트뷰를 전달

        TimeThread(TextView tv) {
            this.tv = tv;
        }


        @Override
        public void run() {

            //1~ 10까지 숫자 세기
            for (int i = 1; i <= 100; i++) {
                Message msg = new Message();
                //Message에는 3개 변수 있음
                //1. Object obj
                //2. int arg1;
                //3. int arg2;

                msg.arg1 = i;
                msg.obj = tv;

                handler.sendMessage(msg);

                try {
                    Log.v("result1", tv1.getText().toString());
                    sleep(1000);
                } catch (InterruptedException e) {
                    Log.v("result1", "방해");
                    return;
                }

            }

//               int n = 0;
//            while (true) {
//
//                tv1.setText("" + n++);
//                try {
//                    Log.v("result", tv1.getText().toString());
//                    sleep(1000);
//                } catch (InterruptedException e) {
//                    Log.v("result", "방해");
//                    return;
//                }
//
//            }

        }


    }

    class TimeThread2 extends Thread {


        private TextView tv;
        TimeThread2(TextView tv) {
            this.tv = tv;
        }
        @Override
        public void run() {
            int n = 0;
            while (true) {

                Message msg = new Message();
                //Message에는 3개 변수 있음
                //1. Object obj
                //2. int arg1;
                //3. int arg2;

                msg.arg1 = n++;
                msg.obj = tv;

                handler.sendMessage(msg);


                try {
                    Log.v("result2", tv2.getText().toString());
                    sleep(1000);
                } catch (InterruptedException e) {
                    Log.v("result2", "방해");
                    return;
                }

            }

        }


    }

}

