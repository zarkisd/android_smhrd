package com.example.pcroom_0205;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    Button[] btns = new Button[9];
    TextView[] tvs = new TextView[9];

    TimeThread[] threads = new TimeThread[9]; //쓰레드 9개 만들어주기

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        for (int i = 0; i < btns.length; i++) {
            final int temp = i; //임시상수 temp에 i값을 복사! (i값에서는 에러가나니! temp로 임시상수를 만들자!!!)
            int btnID = getResources().getIdentifier("btn" + (i + 1), "id", getPackageName());
            int tvID = getResources().getIdentifier("tv" + (i + 1), "id", getPackageName());

            btns[i] = findViewById(btnID);
            tvs[i] = findViewById(tvID);

            //button에 죄석번호 찾기!
            btns[i].setText(i + 1 + "번");
            tvs[i].setText("0원");

            btns[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // OnClickLinstener 객체를 class 내부에서 생성해주었습니다.
                    // Inner Class
                    // Inner Class 에서 바깥에 선언된 변수를 사용할 수 없다.
                    // 변수는 사용할 수 없지만 상수(변하지 않는 수)일 경우에는 사용이 가능!

                    //버튼을 눌렀을때 버튼에 좌석 버튼이 적혀있다면 start 아니면 중지
                    if (btns[temp].getText().equals((temp + 1) + "번")) {
                        threads[temp] = new TimeThread(temp);
                        threads[temp].start();
                    } else {
                        //temp번째 쓰레드 상제로 새치기!
                        // Thread 내부에서는 interruptException 발생!
                        threads[temp].interrupt();
                        btns[temp].setText((temp + 1) + "번");
                        tvs[temp].setText("0원");
                    }

                }
            });
        }
    }

    Handler handler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            if (msg.arg1 % 60 < 10) {
                btns[msg.arg2].setText((msg.arg1 / 60) + " :0" + (msg.arg1 % 60));
            } else {
                btns[msg.arg2].setText((msg.arg1 / 60) + " : " + (msg.arg1 % 60));
            }

            tvs[msg.arg2].setText(((msg.arg1 / 10) * 100) + "원");

        }
    };

    class TimeThread extends Thread {

        private int index; //몇번째 버튼과 텍스트뷰를 동작시켜야 하는지~!

        // 쓰레드 만들었으니 생성자도 만들기!
        public TimeThread(int index) {
            this.index = index;
        }


        @Override
        public void run() {
            // 내가 눌르기 전까지 계속 올라가야하니 while문으로 써준다!
            while (true) {
                int i = 0;
                while (true) {
                    i++;

                    // 여기값이 위에 handleMessage에서 처리된다!!!!
                    Message msg = new Message();
                    msg.arg1 = i; //위에 i++값과 같음
                    msg.arg2 = index; // 몇번째 버튼을 동작시켜야 하는지
                    handler.sendMessage(msg);

                    try {
                        Thread.sleep(1000); // sleep은 예외처리 꼭 해줘야함!
                    } catch (InterruptedException e) {
                        //외부에서 인터럽트 걸면 쓰레드 내부에서 인터럽트 익셉션이 발생
                        //그때 무한반복빠져나가면서 쓰레드는 종료
                        // break 또는 return 쓰기
                        return;
                    }
                }
            }
        }
    }
}