package com.example.a20210128;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button btn_naver, btn_camera, btn_dial, btn_call, btn_next;
    ConstraintLayout cl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_naver = findViewById(R.id.btn_text_naver);
        btn_camera = findViewById(R.id.btn_camera);
        btn_dial = findViewById(R.id.btn_dial);
        btn_call = findViewById(R.id.btn_call);
        btn_next = findViewById(R.id.btn_next);
        cl = findViewById(R.id.layout);


        btn_naver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://m.naver.com"));
                startActivity(myIntent);
            }
        });

        btn_camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivity(intent);

            }
        });

        btn_dial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:01043939206"));
                startActivity(myIntent);
            }
        });
        //전화걸기는 하드웨어를 제어하기때문에 민감한 기능
        //파일 읽기 쓰기 위치액세스
        //보안을 위해 민감한 기능에 대해 권한을 주도록 설정되어있다
        // permission
        btn_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent myIntent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:01043939206"));

                //권한 승인받는 코드
                if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CALL_PHONE)
                        != PackageManager.PERMISSION_GRANTED) {
                    //현재 앱에 CALL_PHONE 권한이 부여되어 있지 않다면
                    //권한 요청
                    ActivityCompat.requestPermissions(MainActivity.this,
                            new String[]{
                                    Manifest.permission.CALL_PHONE
                            }, 0);

                } else {
                    startActivity(myIntent);
                }
            }
        });

        btn_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ColorActivity.class);
                startActivityForResult(intent, 0);

            }
        });

    }


    //다시 돌아왔을때 실행될 메소드
    //alt+insert 누르고 orerride methods 클릭

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //배경색 바꾸는 코드!!
        if(resultCode==RESULT_OK){
            //결과가 잘 넘어왔다면
            if(requestCode==0){
                //배경색 버튼을 눌러서 다녀온거라면
                //1. 키값 2. 키값에 해당하는 데이터가 없을때 기본값
                int color=data.getIntExtra("color", 0);

                switch(color){
                    case 0:
                        cl.setBackgroundColor(Color.parseColor("#ec4646"));
                        break;
                    case 1:
                        cl.setBackgroundColor(Color.parseColor("#16c79a"));
                        break;
                    case 2:
                        cl.setBackgroundColor(Color.parseColor("#1a508b"));
                        break;
                }

                /*  if(color==0) {
                    cl.setBackgroundColor(Color.parseColor("#ec4646"));
                }
                else if(color==1){
                    cl.setBackgroundColor(Color.parseColor("#16c79a"));
                }
                else{
                    cl.setBackgroundColor(Color.parseColor("#1a508b"));
                }
*/


            }
        }


    }

}