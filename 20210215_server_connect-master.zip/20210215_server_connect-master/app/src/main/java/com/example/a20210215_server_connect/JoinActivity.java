package com.example.a20210215_server_connect;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class JoinActivity extends AppCompatActivity {
    EditText edt_inputid;
    EditText edt_inputpw;
    Button btn_inputjoin;

    RequestQueue requestQueue; //데이터가 전송되는 통로
    StringRequest stringRequest; // 내가 보낼 데이터

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join);

        edt_inputid = findViewById(R.id.edt_joinid);
        edt_inputpw = findViewById(R.id.edt_joinpw);
        btn_inputjoin = findViewById(R.id.btn_inputjoin);
        Handler mHandler = new Handler(Looper.getMainLooper());


        //requestQueue 생성!
        requestQueue = Volley.newRequestQueue(this);
        //requestQueue = Volley.newRequestQueue(getApplicationContext());
        // 접속하고 싶은 url!!
        //String url = "http://172.30.1.3:8081/LoginServer/JoinServlet";
        //내꺼
        //String url = "http://172.30.1.5:8081/LoginServer/JoinServlet";
        //샘
        String url = "http://172.30.1.10:8081/LoginServer/JoinServlet";
        //유정
        // stringRequest 생성!


        stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                //응답을 감지하는 Listener
                if (response.equals("1")) {
                    Toast.makeText(JoinActivity.this, "가입 성공",Toast.LENGTH_SHORT ).show();
                }
                else{
                    Toast.makeText(JoinActivity.this, "가입 실패...",Toast.LENGTH_SHORT ).show();

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {
            //StringRequest 내의 메소드 오버로딩!
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                //서버에 전송하고 싶은 데이터를 key값, value값으로 저장하여 return!
                Map<String, String> data = new HashMap<>();
                data.put("id", edt_inputid.getText().toString());
                data.put("pw", edt_inputpw.getText().toString());

                return data;
            }
        };


        //stringRequest를 구분하기 위한 태그 달기
        stringRequest.setTag("MAIN");
        btn_inputjoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //requestQuese를 통해 stringRequest 전송하기!
                requestQueue.add(stringRequest);
            }
        });


    }
}
