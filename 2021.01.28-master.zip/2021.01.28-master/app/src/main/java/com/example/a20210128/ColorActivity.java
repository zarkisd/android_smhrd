package com.example.a20210128;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class ColorActivity extends AppCompatActivity {
    ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_color);

        lv = findViewById(R.id.colorlist);

        //ListView화면 누르면 MainActivity로 돌아가기기
        //ListView 항목 클릭 감지 객체 리스너
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //parent -> listview 자체
                //view -> 하나의 항목 뷰
                //position -> 항목 번호 red-0 green 1 blue 2
                //id -> 각 뷰의 고유 id(R.id 아님)
                Intent myintent = new Intent();
                //포지션 값을 저장하기 위한 껍데기
                myintent.putExtra("color", position);
                
                //ColorActivity 실행시킨곳으로 다시 돌아감
                //1 응답코드 2. 값을 보내고 싶을때 값이 담겨있는 intent

                setResult(RESULT_OK, myintent);
                finish();
            }
        });

    }
}
