package com.example.a20210201;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    TextView txt_go;
    ListView list_go;
    Button btn_add;
    ArrayList<String[]> go_data = new ArrayList<>();
    GoAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txt_go = findViewById(R.id.txt_go);
        list_go = findViewById(R.id.list_go);
        btn_add = findViewById(R.id.btn_add);

        go_data.add(new String[]{"네이버", "http://m.naver.com"});
        go_data.add(new String[]{"다음", "http://www.daum.net"});
        go_data.add(new String[]{"네이트", "http://m.nate.com"});
        go_data.add(new String[]{"스미원", "http://www.smhrd.or.kr"});
        go_data.add(new String[]{"유튜브", "http://m.youtube.com"});

        adapter = new GoAdapter(MainActivity.this, R.layout.directlist, (ArrayList<String[]>) go_data);

        list_go.setAdapter(adapter);


        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myintent = new Intent(MainActivity.this, AddList.class);
                startActivityForResult(myintent, 0);
            }
        });

/*리스트 뷰안에 들어있는 TextView나 Button에 Event를 줄떄는 Adapter - > getView!
    리스트 뷰 한 줄 통째에 Event를 주고 싶은때는 MainActivity -> listView!
 */
        list_go.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                //parent - > event가 발생한 ListView 자체
                //view - > event 가 발생한 항목 view(세트  텍뷰 + 버튼 세트~)
                //position -> 이벤트가 발생한 항목의 인덱스!
                // id 이벤트가 발생한 항목의 id값!(position과 같은 값!)

                //return false였을때는 Longclick과 일반 click 같이 쓸수 없음
                //return true였을때 같이 사용가능
                // 안되면 button 속성의 focusable clickable 둘다 false
                //카카오톡 채팅기능 클릭하면 채팅들어가지고 롱클릭하면 메뉴뜸
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
//context 화면 구성 정보가 담긴 객체 가져오기

                builder.setTitle("삭제하기");
                builder.setMessage("진짜로?");
                //오른쪽 버튼
                builder.setPositiveButton("예", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        go_data.remove(position);
                        adapter.notifyDataSetChanged();
                    }
                });
                //왼쪽 버튼
                builder.setNegativeButton("cancel", null);

                builder.show();


                return true;
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == 0) {
                String[] get_data = data.getStringArrayExtra("value");
                //만약 어레이리스트 변수명이 data라면
                // this.를 붙여줘서 메소드의 매개변수와 필드변수 data를 구분해야한다
                go_data.add(get_data);
                adapter.notifyDataSetChanged();


            }


        }
    }
}