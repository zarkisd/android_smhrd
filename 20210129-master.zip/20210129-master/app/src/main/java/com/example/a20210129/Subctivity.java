package com.example.a20210129;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Subctivity extends AppCompatActivity {

    EditText edt_id;
    EditText edt_pw;
    Button btn_check_login;
    String id="junho";
    String pw="1234";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subctivity);

        edt_id=(EditText)findViewById(R.id.edt_id);
        edt_pw=(EditText)findViewById(R.id.edt_pw);
        btn_check_login=findViewById(R.id.btn_check_login);

        btn_check_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.v("value", "버튼 클릭(로그인 체크)");

                String id_input=edt_id.getText().toString();
                String pw_input=edt_pw.getText().toString();

                if(id_input.equals(id)&&pw_input.equals(pw)) {
                    Toast.makeText(Subctivity.this, "Success", Toast.LENGTH_SHORT).show();
                    Log.v("value", "로그인 성공");

                    Intent myintent = new Intent();

                    myintent.putExtra("ID", id_input);

                    setResult(RESULT_OK, myintent);

                    finish();
                }
                else{
                    Toast.makeText(Subctivity.this, "fail...", Toast.LENGTH_SHORT).show();
                    Log.v("value", "로그인 실패");
                }
            }
        });

    }
}